#!perl
use Horse;
use Sheep;

my $horse = Horse->named('Glob');
$horse->eat('grass');
$horse->set_color('bloody red');
print $horse->{Name}, " is ", $horse->{Color}, "\n";

Sheep->eat('grass');


