use v5.16;
use strict;
use Person;
our @ISA = qw(Person);

print "Please input the words you want to say:";
chomp(my $words = <STDIN>);
my $person = 'Person';
$person->speak($words);
